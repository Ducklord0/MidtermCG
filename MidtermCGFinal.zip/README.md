# MidtermCG
I used a toonramp shader to make the main part of the ship. I would have tried to add a outline to give it that out cartoon feeling if i had time. The background is a simple picture. I would have done a bump map with more time to make it stick out. 
I made a hurt effect using the lut. When 1 is pressed it turns to a redder tint so you can tell you took damage. 2 makes it go back.
The reflection i used is the base reflection we used in class mainly using smoothness and metallics and changing their values to get a realistic reflection
